/*
 * model to use
 */

MODEL = {
    BLOCK: 1,
    PACMAN: 2,
    MONSTER: 3,
    PELLET: 4,
	SUPERPELLET: 5,
};
