def ("Picker") ({
    init: function () {
        this.colorMap = [];

    },
    /*
     * add object to identify
     */
    track: function (obj) {
        this.colorMap.push(obj);
    },
    /*
     * create and draw pick test
     */
    createPickTest: function () {

    },
    /*
     * say what is picked
     */
    what: function(){

    }
});
