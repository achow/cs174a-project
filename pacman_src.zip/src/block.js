def ("Block") << Obj ({

    init: function(world, id) {
        this._super(world, id);
        this.color.setColor(0.0, 0.0, 1.0);
        //this.skin = "block skin";
    },
});
